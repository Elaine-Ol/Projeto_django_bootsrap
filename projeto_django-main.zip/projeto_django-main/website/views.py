from django.shortcuts import render
from funcionario.models import Funcionarios
from django.db import models

def index(request):
    # Buscar todos os funcionários
    funcionarios = Funcionarios.objectos.all()
    
    # Calcular estatísticas
    total_funcionarios = funcionarios.count()
    tempo_medio = funcionarios.aggregate(models.Avg('tempo_de_servico'))['tempo_de_servico__avg'] or 0
    salario_medio = funcionarios.aggregate(models.Avg('remuneracao'))['remuneracao__avg'] or 0
    
    context = {
        'funcionarios': funcionarios,
        'total_funcionarios': total_funcionarios,
        'tempo_medio': round(tempo_medio, 1),
        'salario_medio': round(salario_medio, 2),
    }
    
    return render(request, 'website/index.html', context)