from django.contrib import admin

from funcionario.models import Funcionarios
admin.site.register(Funcionarios)


# Register your models here.
